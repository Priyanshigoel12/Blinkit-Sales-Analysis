# 📊 Blinkit Sales Analysis — Power BI

A clean, beginner‑friendly **Power BI** project analyzing Blinkit grocery sales to surface KPIs, category trends, and actionable business insights.

---

## 🔎 What’s inside
- **Interactive Power BI report** (`dashboard/blinkit.pbix`)
- **Source data** (`data/BlinkIT Grocery Data.xlsx`)
- **Images** (screenshots used in this README)

```
Blinkit-Sales-Analysis/
├─ data/
│  └─ BlinkIT Grocery Data.xlsx
├─ dashboard/
│  └─ blinkit.pbix
├─ images/
│  ├─ dashboard-overview.png
│  └─ category-performance.png
└─ README.md
```

---

## 🎯 Business Questions
- Which **categories** drive the highest revenue and orders?
- How do **monthly sales trends** evolve (seasonality / growth)?
- Who are the **top SKUs** and what’s their contribution?
- What **promotions or bundles** could lift revenue?

---

## 🧮 Key Metrics (examples)
- **Total Sales**, **Total Orders**, **Avg. Basket Value**
- **Revenue by Category / Sub‑Category**
- **Top 10 Products by Sales**
- **Month‑over‑Month Growth %**

> DAX measures (if applicable) are built directly in the `.pbix` file.

---

## 📸 Dashboard Preview
> Replace these placeholders with real screenshots exported from Power BI.

![Overview](images/dashboard-overview.png)
![Category Performance](images/category-performance.png)

**How to replace:** Open the report in Power BI Desktop → capture screenshots (Snipping Tool on Windows or Shift‑Cmd‑4 on Mac) → save into `images/` with the same filenames.

---

## 🛠 Tools
- **Power BI Desktop** for modeling & visuals
- **Excel** for quick data checks
- **DAX** for calculated measures

---

## 🚀 How to Run
1. Download this repository (Code ▸ Download ZIP) or clone it.
2. Open `dashboard/blinkit.pbix` in **Power BI Desktop**.
3. If prompted, update data source path to `data/BlinkIT Grocery Data.xlsx`.
4. Refresh and explore the report.

---

## ✨ Author
**Priyanshi Goel**  
LinkedIn: _add your link_ • GitHub: _add your link_

> If you found this useful, please ⭐ star the repo!
